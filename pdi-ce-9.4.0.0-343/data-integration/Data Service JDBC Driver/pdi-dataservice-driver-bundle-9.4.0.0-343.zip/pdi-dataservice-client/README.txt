The pdi-dataservice-client zip contains all of the jar files required to make a JDBC connection to a running Data Service.

Configuration documentation can be found at https://help.hitachivantara.com/Documentation/Pentaho/9.4/Products/Pentaho_Data_Services
